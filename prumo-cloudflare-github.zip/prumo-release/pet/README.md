# Pru
Mascote integrado à Mesa. Os comandos locais não usam IA. O botão Me ajude abre o chat e mostra “Olá! No que posso ajudar?”. Cada envio chama POST /api/research e consome um crédito diário no servidor.
