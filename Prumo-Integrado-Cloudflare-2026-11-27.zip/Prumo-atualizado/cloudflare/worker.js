/*
 * PRUMO API — Cloudflare Worker + D1 + Workers AI
 * Chat híbrido: FAQ local primeiro; Workers AI para perguntas abertas.
 * Rotas: GET /api/health, POST /api/register, POST /api/login,
 * GET /api/me, POST /api/chat (alias legado: POST /api/research).
 * Nenhuma chave da OpenAI é necessária para o chatbot.
 */
const encoder = new TextEncoder();
const DAILY_LIMIT_DEFAULT = 2;
const TOKEN_DAYS = 7;
const PASSWORD_ITERATIONS = 180000;
const DEFAULT_MODEL = "@cf/zai-org/glm-4.7-flash";
const SYSTEM_PROMPT = `Você é o assistente virtual do Prumo, uma agência criativa e ambiente de trabalho de marketing.
Fale em português brasileiro, com clareza, cordialidade e criatividade, sem exagerar em emojis.
Ajude com estratégia de marketing, branding, conteúdo, campanhas, posicionamento, redação, revisão e organização de tarefas, além de orientar sobre a Mesa do Prumo.
Não invente preços, prazos, clientes, resultados, contatos, dados institucionais ou funcionalidades. Se não souber uma informação específica da agência, diga que precisa ser confirmada pela equipe.
Não afirme que publicou campanhas, enviou mensagens ou alterou dados: você apenas orienta, a menos que uma ferramenta real tenha executado a ação.
Quando fizer sentido, dê passos práticos e exemplos. Diferencie fatos de sugestões.`;

const FAQ = [
  { keys: ["o que e prumo", "sobre o prumo", "quem e prumo", "o que voces fazem", "o que faz o prumo"], answer: "O Prumo é uma casa de marketing com uma Mesa de Agência para apoiar a organização de atividades como campanhas, conteúdo, gestão, criação e auditoria. Posso ajudar você a entender os módulos e pensar em estratégias." },
  { keys: ["como funciona a mesa", "mesa da agencia", "modulos", "ferramentas da mesa", "como usar a mesa"], answer: "A Mesa reúne ferramentas de trabalho da agência. Use a navegação lateral para acessar os módulos disponíveis, abrir uma ferramenta e organizar suas atividades. Os recursos exibidos dependem da versão e das configurações do projeto." },
  { keys: ["contato", "telefone", "email da agencia", "orcamento", "preco", "valor dos servicos"], answer: "Não tenho um preço ou contato oficial confirmado cadastrado. Para evitar passar uma informação incorreta, confirme esses dados diretamente com a equipe do Prumo." },
  { keys: ["creditos", "limite diario", "quantas mensagens", "cota", "mensagens por dia"], answer: "O assistente oferece até 2 mensagens por conta a cada dia. Cada mensagem enviada consome 1 crédito, inclusive respostas da base de perguntas frequentes. A abertura do chat e o comando /pet não consomem créditos." },
  { keys: ["como chamar o pru", "como trazer o pet", "comando pet", "pet voltar", "/pet"], answer: "Digite /pet no campo de mensagem e envie. O comando é executado localmente, faz o Pru reaparecer e não consome créditos do assistente." },
  { keys: ["suma", "esconder o pru", "ocultar o pet", "sumir com o pet"], answer: "Use a ação Suma no mascote para ocultá-lo com o efeito de partículas. Para trazê-lo de volta, digite /pet no chat da Mesa." },
  { keys: ["a ia e gratuita", "chatbot gratuito", "openai", "chave da openai"], answer: "O chatbot de texto desta versão usa o Workers AI da Cloudflare, sem exigir uma chave da OpenAI. O uso depende dos limites e das condições vigentes da Cloudflare. A ferramenta de geração de imagens é separada e pode ter configuração própria." }
];

function corsHeaders(request, env) {
  const origin = request.headers.get("Origin") || "";
  const allowed = (env.ALLOWED_ORIGINS || "*").split(",").map(x => x.trim()).filter(Boolean);
  const permitted = !origin || allowed.includes("*") || allowed.includes(origin);
  return {
    "Access-Control-Allow-Origin": permitted ? (allowed.includes("*") ? "*" : (origin || allowed[0] || "*")) : "null",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}
function json(data, status, request, env) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...corsHeaders(request, env) }
  });
}
function b64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromB64url(value) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}
function randomBytes(size) { const out = new Uint8Array(size); crypto.getRandomValues(out); return out; }
function hex(bytes) { return [...bytes].map(b => b.toString(16).padStart(2, "0")).join(""); }
function unhex(value) { return new Uint8Array((String(value).match(/.{1,2}/g) || []).map(x => parseInt(x, 16))); }
function safeEqual(a, b) {
  a = String(a || ""); b = String(b || "");
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
async function passwordHash(password, saltHex) {
  const salt = saltHex ? unhex(saltHex) : randomBytes(16);
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: PASSWORD_ITERATIONS, hash: "SHA-256" }, key, 256);
  return { salt: hex(salt), hash: hex(new Uint8Array(bits)) };
}
async function signToken(payload, secret) {
  const header = b64url(encoder.encode(JSON.stringify({ alg: "HS256", typ: "JWT" })));
  const body = b64url(encoder.encode(JSON.stringify(payload)));
  const data = `${header}.${body}`;
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(data));
  return `${data}.${b64url(new Uint8Array(signature))}`;
}
async function verifyToken(token, secret) {
  try {
    const [header, body, signature] = String(token || "").split(".");
    if (!header || !body || !signature) return null;
    const data = `${header}.${body}`;
    const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    const ok = await crypto.subtle.verify("HMAC", key, fromB64url(signature), encoder.encode(data));
    if (!ok) return null;
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(body)));
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000) || !payload.email) return null;
    return payload;
  } catch { return null; }
}
async function currentUser(request, env) {
  const auth = request.headers.get("Authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token || !env.JWT_SECRET) return null;
  const payload = await verifyToken(token, env.JWT_SECRET);
  if (!payload) return null;
  return await env.DB.prepare("SELECT email, name FROM users WHERE email = ?1").bind(payload.email).first();
}
function currentDay(env) {
  const zone = env.APP_TIME_ZONE || "America/Fortaleza";
  return new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}
function dailyLimit(env) { return Math.max(1, Math.min(20, Number(env.DAILY_CREDITS || DAILY_LIMIT_DEFAULT))); }
async function quotaFor(env, email, day = currentDay(env)) {
  const row = await env.DB.prepare("SELECT used FROM daily_usage WHERE email = ?1 AND day = ?2").bind(email, day).first();
  const limit = dailyLimit(env);
  const used = Number(row?.used || 0);
  return { used, limit, remaining: Math.max(0, limit - used), day };
}
async function reserveCredit(env, email, day, limit) {
  return env.DB.prepare(`INSERT INTO daily_usage (email, day, used) VALUES (?1, ?2, 1)
    ON CONFLICT(email, day) DO UPDATE SET used = used + 1 WHERE used < ?3
    RETURNING used`).bind(email, day, limit).first();
}
async function refundCredit(env, email, day) {
  await env.DB.prepare("UPDATE daily_usage SET used = CASE WHEN used > 0 THEN used - 1 ELSE 0 END WHERE email = ?1 AND day = ?2").bind(email, day).run();
}
function normalize(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[^\p{L}\p{N}\s/]/gu, " ").replace(/\s+/g, " ").trim();
}
function findFaqAnswer(question) {
  const q = normalize(question);
  for (const item of FAQ) {
    if (item.keys.some(key => q.includes(normalize(key)))) return item.answer;
  }
  return null;
}
function cleanMessages(messages, question) {
  let list = Array.isArray(messages) ? messages : [];
  if (!list.length && question) list = [{ role: "user", content: String(question) }];
  return list.slice(-12).map(m => ({
    role: m?.role === "assistant" ? "assistant" : "user",
    content: String(m?.content || "").slice(0, 4000)
  })).filter(m => m.content.trim());
}
function extractAiText(result) {
  if (typeof result === "string") return result.trim();
  const candidates = [result?.response, result?.result?.response, result?.output_text,
    result?.choices?.[0]?.message?.content, result?.content?.[0]?.text];
  return candidates.find(x => typeof x === "string" && x.trim())?.trim() || "";
}
async function requireUser(request, env) { return currentUser(request, env); }

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(request, env) });
    const { pathname: path } = new URL(request.url);
    if (request.method === "GET" && path === "/api/health") {
      return json({ ok: true, service: "prumo-api", ai: Boolean(env.AI), model: env.AI_MODEL || DEFAULT_MODEL, time: new Date().toISOString() }, 200, request, env);
    }
    if (!env.DB) return json({ error: "Banco D1 não está vinculado ao Worker (binding DB)." }, 500, request, env);
    try {
      if (request.method === "POST" && path === "/api/register") {
        if (!env.JWT_SECRET) return json({ error: "Configure o Secret JWT_SECRET no Worker." }, 500, request, env);
        const body = await request.json();
        const name = String(body.name || "").trim().slice(0, 80);
        const email = String(body.email || "").trim().toLowerCase().slice(0, 190);
        const password = String(body.password || "");
        if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Informe nome e e-mail válidos." }, 400, request, env);
        if (password.length < 10 || password.length > 128) return json({ error: "A senha precisa ter entre 10 e 128 caracteres." }, 400, request, env);
        const creds = await passwordHash(password);
        try {
          await env.DB.prepare("INSERT INTO users (email, name, password_salt, password_hash, created_at) VALUES (?1, ?2, ?3, ?4, ?5)")
            .bind(email, name, creds.salt, creds.hash, Math.floor(Date.now() / 1000)).run();
        } catch (error) {
          if (String(error).toLowerCase().includes("unique") || String(error).toLowerCase().includes("constraint")) return json({ error: "Já existe uma conta online com este e-mail. Entre nela." }, 409, request, env);
          throw error;
        }
        const now = Math.floor(Date.now() / 1000);
        const token = await signToken({ email, iat: now, exp: now + TOKEN_DAYS * 86400 }, env.JWT_SECRET);
        return json({ token, user: { email, name }, quota: await quotaFor(env, email) }, 201, request, env);
      }
      if (request.method === "POST" && path === "/api/login") {
        if (!env.JWT_SECRET) return json({ error: "Configure o Secret JWT_SECRET no Worker." }, 500, request, env);
        const body = await request.json();
        const email = String(body.email || "").trim().toLowerCase().slice(0, 190);
        const password = String(body.password || "");
        const user = await env.DB.prepare("SELECT email, name, password_salt, password_hash FROM users WHERE email = ?1").bind(email).first();
        if (!user || password.length > 128) return json({ error: "E-mail ou senha incorretos." }, 401, request, env);
        const candidate = await passwordHash(password, user.password_salt);
        if (!safeEqual(candidate.hash, user.password_hash)) return json({ error: "E-mail ou senha incorretos." }, 401, request, env);
        const now = Math.floor(Date.now() / 1000);
        const token = await signToken({ email, iat: now, exp: now + TOKEN_DAYS * 86400 }, env.JWT_SECRET);
        return json({ token, user: { email, name: user.name }, quota: await quotaFor(env, email) }, 200, request, env);
      }
      if (request.method === "GET" && path === "/api/me") {
        const user = await requireUser(request, env);
        if (!user) return json({ error: "Sessão inválida ou expirada. Entre novamente." }, 401, request, env);
        return json({ user: { email: user.email, name: user.name }, quota: await quotaFor(env, user.email) }, 200, request, env);
      }
      if (request.method === "POST" && (path === "/api/chat" || path === "/api/research")) {
        const user = await requireUser(request, env);
        if (!user) return json({ error: "Sessão inválida ou expirada. Entre novamente." }, 401, request, env);
        const body = await request.json();
        const messages = cleanMessages(body.messages, body.question);
        if (!messages.length || messages[messages.length - 1].role !== "user") return json({ error: "Envie uma mensagem válida." }, 400, request, env);
        const question = messages[messages.length - 1].content;
        if (!question.trim()) return json({ error: "A mensagem não pode estar vazia." }, 400, request, env);

        const day = currentDay(env);
        const limit = dailyLimit(env);
        const reserved = await reserveCredit(env, user.email, day, limit);
        if (!reserved) {
          const quota = await quotaFor(env, user.email, day);
          return json({ error: `Você usou seus ${limit} créditos de hoje. Volte amanhã para continuar.`, quota }, 429, request, env);
        }
        try {
          const staticAnswer = findFaqAnswer(question);
          let answer = staticAnswer;
          let source = "faq";
          let model = null;
          if (!answer) {
            if (!env.AI || typeof env.AI.run !== "function") throw new Error("Workers AI não está vinculado. Configure [ai] binding = \"AI\".");
            model = env.AI_MODEL || DEFAULT_MODEL;
            const history = messages.slice(0, -1);
            const result = await env.AI.run(model, {
              messages: [{ role: "system", content: SYSTEM_PROMPT }, ...history, { role: "user", content: question }],
              max_tokens: 700,
              temperature: 0.55
            });
            answer = extractAiText(result);
            if (!answer) throw new Error("O modelo não retornou texto nesta resposta.");
            source = "ai";
          }
          const quota = await quotaFor(env, user.email, day);
          return json({ answer, source, model, quota }, 200, request, env);
        } catch (error) {
          await refundCredit(env, user.email, day);
          const quota = await quotaFor(env, user.email, day);
          console.error("Prumo chat error:", error?.message || error);
          return json({ error: "Não consegui responder agora. Seu crédito foi devolvido; confira a configuração do Workers AI e tente novamente.", detail: String(error?.message || error).slice(0, 240), quota }, 503, request, env);
        }
      }
      return json({ error: "Rota não encontrada." }, 404, request, env);
    } catch (error) {
      console.error("Prumo Worker error:", error?.message || error);
      return json({ error: "Erro interno no servidor do Prumo. Confira os Logs do Worker." }, 500, request, env);
    }
  }
};
